"""Protected Web Application with DDoS Defense - Production Release"""
from flask import Flask, request, jsonify, render_template_string, g, redirect, url_for, session
from functools import wraps
import time
import sys
import os
import logging
import secrets
import hmac
import threading
from datetime import timedelta
from urllib.parse import urlparse
from werkzeug.security import check_password_hash

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger(__name__)

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from detection.ddos_detector import DDoSDetector, TrafficMetrics
from mitigation.rate_limiter import RateLimiter, TrafficAnalyzer
from mitigation.notifier import AttackNotifier
from recovery.health_monitor import HealthMonitor

app = Flask(__name__)

# App/session security config
app.config['SECRET_KEY'] = os.environ.get('FLASK_SECRET_KEY') or secrets.token_hex(32)
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = os.environ.get('SESSION_COOKIE_SECURE', 'false').lower() == 'true'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(
    seconds=int(os.environ.get('SESSION_MAX_AGE_SECONDS', 43200))
)

# Admin credentials
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD')
ADMIN_PASSWORD_HASH = os.environ.get('ADMIN_PASSWORD_HASH')

# Admin API key (optional fallback for programmatic access)
ADMIN_API_KEY = os.environ.get('ADMIN_API_KEY', 'change-me-in-production')
LOGIN_MAX_ATTEMPTS = int(os.environ.get('LOGIN_MAX_ATTEMPTS', 5))
LOGIN_LOCK_SECONDS = int(os.environ.get('LOGIN_LOCK_SECONDS', 300))
LOGIN_ATTEMPTS = {}

if not ADMIN_PASSWORD and not ADMIN_PASSWORD_HASH:
    ADMIN_PASSWORD = 'change-me-now'
    logger.warning("No ADMIN_PASSWORD/ADMIN_PASSWORD_HASH configured; using insecure default password.")

# Initialize all core components (configurable via environment variables)
detector = DDoSDetector(
    time_window=int(os.environ.get('TIME_WINDOW', 60)),
    requests_threshold=int(os.environ.get('DETECTION_THRESHOLD', 50)),
    unique_ip_threshold=int(os.environ.get('UNIQUE_IP_THRESHOLD', 50))
)
rate_limiter = RateLimiter(
    default_rate=int(os.environ.get('RATE_LIMIT', 100)),
    default_burst=int(os.environ.get('BURST_SIZE', 20))
)
traffic_analyzer = TrafficAnalyzer()
health_monitor = HealthMonitor(
    failure_threshold=int(os.environ.get('FAILURE_THRESHOLD', 3)),
    recovery_time=int(os.environ.get('RECOVERY_TIME', 300))
)
notifier = AttackNotifier(
    webhook_url=os.environ.get('WEBHOOK_URL'),
    cooldown=int(os.environ.get('ALERT_COOLDOWN', 60))
)
health_monitor.register_service('web_app')

def background_cleanup():
    """Background thread for periodic cleaning of stale rate limiter buckets and old IP blocks."""
    while True:
        try:
            rate_limiter.cleanup_stale_buckets()
            # Automatically unblock IPs older than 1 hour (default)
            pruned_count = detector.prune_blocks(max_age=int(os.environ.get('BLOCK_EXPIRY', 3600)))
            if pruned_count > 0:
                logger.info("Background cleanup: unblocked %d expired IPs", pruned_count)
        except Exception as e:
            logger.error("Error in background cleanup thread: %s", e)
        time.sleep(60)

# Start background cleanup thread
cleanup_thread = threading.Thread(target=background_cleanup, daemon=True)
cleanup_thread.start()

# Per-endpoint rate limit profiles: path_prefix -> (rate_per_min, burst)
ENDPOINT_RATE_PROFILES = {
    '/login': (10, 5),
    '/admin': (30, 10),
    '/api': (200, 50),
}


def require_admin(f):
    """Decorator to require authenticated admin session (or API key fallback)."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not is_admin_authenticated():
            if request.path.startswith('/admin/dashboard'):
                return redirect(url_for('admin_login', next=request.full_path))
            return jsonify({'error': 'Unauthorized', 'code': 'AUTH_REQUIRED'}), 401
        return f(*args, **kwargs)
    return decorated


def _get_admin_api_key():
    return (request.headers.get('X-API-Key')
            or request.args.get('api_key'))


def _is_safe_next_url(target: str) -> bool:
    if not target:
        return False
    parsed = urlparse(target)
    return (not parsed.netloc) and target.startswith('/admin')


def verify_admin_password(password: str) -> bool:
    if not password:
        return False
    if ADMIN_PASSWORD_HASH:
        try:
            return check_password_hash(ADMIN_PASSWORD_HASH, password)
        except Exception:
            logger.exception("Failed to verify ADMIN_PASSWORD_HASH")
            return False
    return bool(ADMIN_PASSWORD) and hmac.compare_digest(password, ADMIN_PASSWORD)


def _login_bucket_key(ip: str) -> str:
    return ip or 'unknown'


def is_login_locked(ip: str) -> bool:
    state = LOGIN_ATTEMPTS.get(_login_bucket_key(ip))
    if not state:
        return False
    locked_until = state.get('locked_until', 0)
    if locked_until > time.time():
        return True
    if locked_until:
        LOGIN_ATTEMPTS.pop(_login_bucket_key(ip), None)
    return False


def register_login_failure(ip: str):
    key = _login_bucket_key(ip)
    state = LOGIN_ATTEMPTS.get(key, {'count': 0, 'locked_until': 0})
    state['count'] = state.get('count', 0) + 1
    if state['count'] >= LOGIN_MAX_ATTEMPTS:
        state['locked_until'] = time.time() + LOGIN_LOCK_SECONDS
        state['count'] = 0
    LOGIN_ATTEMPTS[key] = state


def clear_login_failures(ip: str):
    LOGIN_ATTEMPTS.pop(_login_bucket_key(ip), None)


def is_admin_authenticated() -> bool:
    if session.get('admin_authenticated') and session.get('admin_username') == ADMIN_USERNAME:
        return True

    # API key fallback for scripts/automation clients.
    api_key = _get_admin_api_key()
    if api_key and hmac.compare_digest(api_key, ADMIN_API_KEY):
        return True
    return False


def get_client_ip():
    """Get real client IP, even behind Nginx reverse proxy."""
    return (request.headers.get('X-Real-IP')
            or request.headers.get('X-Forwarded-For', '').split(',')[0].strip()
            or request.remote_addr
            or 'unknown')


def get_rate_profile(path):
    """Get rate limit profile for the given endpoint path."""
    for prefix, profile in ENDPOINT_RATE_PROFILES.items():
        if path.startswith(prefix):
            return profile
    return None


def classify_ip_location(ip: str) -> str:
    """Resolve location from notifier service (GeoIP-aware with safe fallback)."""
    return notifier.classify_ip_location(ip)


@app.before_request
def ddos_protection():
    g.start_time = time.time()
    client_ip = get_client_ip()

    # Allow health check endpoint to bypass all DDoS checks
    if request.path == '/health':
        return None

    # Allow admin login/logout and authenticated admin requests to bypass DDoS checks
    if request.path in ('/admin/login', '/admin/logout'):
        return None
    if request.path.startswith('/admin') and is_admin_authenticated():
        return None

    # Check if IP is blocked by detector
    if detector.is_blocked(client_ip):
        logger.info("Blocked request from %s", client_ip)
        return jsonify({'error': 'IP blocked', 'code': 'IP_BLOCKED'}), 403

    # Check rate limit (per-endpoint profiles override global)
    profile = get_rate_profile(request.path)
    if profile:
        allowed, info = rate_limiter.check_rate_limit(
            f"{client_ip}:{request.path}", rate=profile[0], burst=profile[1]
        )
    else:
        allowed, info = rate_limiter.check_rate_limit(client_ip)

    if not allowed:
        logger.info("Rate limited %s (retry_after=%s)", client_ip, info.get('retry_after'))
        response = jsonify({
            'error': 'Rate limit exceeded',
            'code': 'RATE_LIMITED',
            'retry_after': info.get('retry_after', 1)
        })
        response.status_code = 429
        response.headers['Retry-After'] = str(info.get('retry_after', 1))
        return response


@app.after_request
def analyze_traffic(response):
    response_time = time.time() - g.get('start_time', time.time())
    client_ip = get_client_ip()

    # Skip traffic analysis for health checks and authenticated admin requests
    if request.path == '/health':
        return response
    if request.path in ('/admin/login', '/admin/logout'):
        return response
    if request.path.startswith('/admin') and is_admin_authenticated():
        return response

    # Feed traffic to detection engine
    metric = TrafficMetrics(
        timestamp=time.time(),
        ip_address=client_ip,
        user_agent=request.headers.get('User-Agent', 'Unknown'),
        endpoint=request.path,
        method=request.method,
        status_code=response.status_code,
        response_time=response_time,
        payload_size=response.content_length or 0
    )
    is_attack, signature = detector.analyze_traffic(metric)

    if is_attack and signature:
        logger.warning("Attack detected: %s from %s (confidence=%.2f)",
                       signature.attack_type, client_ip, signature.confidence)
        health_monitor.report_failure('web_app')
        notifier.notify(
            attack_type=signature.attack_type,
            source_ip=client_ip,
            confidence=signature.confidence,
            severity=signature.severity,
            details=f"endpoint={request.path}"
        )
    else:
        health_monitor.report_success('web_app')

    # Feed to traffic analyzer for risk scoring
    risk = traffic_analyzer.analyze_request(
        ip=client_ip, endpoint=request.path, method=request.method,
        user_agent=request.headers.get('User-Agent', 'Unknown'),
        status_code=response.status_code, response_time=response_time
    )

    if risk['recommendation'] == 'BLOCK_IMMEDIATELY' and not detector.is_blocked(client_ip):
        detector._persist_block(client_ip)
        logger.warning("TrafficAnalyzer blocked IP %s (score=%.1f, risk=%s)",
                       client_ip, risk['suspicious_score'], risk['risk_level'])
        notifier.notify(
            attack_type='BEHAVIORAL_BLOCK',
            source_ip=client_ip,
            confidence=risk['suspicious_score'] / 100.0,
            severity='CRITICAL',
            details=f"risk={risk['risk_level']}"
        )

    # Add security headers
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'

    return response


# ==================== Public Routes ====================

@app.route('/')
def home():
    return render_template_string(LANDING_PAGE_HTML)


@app.route('/health')
def health():
    # Restrict detailed health info: allow local requests or authenticated admin/API key
    remote = request.remote_addr
    overall = health_monitor.get_overall_health()
    if is_admin_authenticated() or remote in ('127.0.0.1', '::1'):
        return jsonify({
            'status': overall['status'].lower(),
            'timestamp': time.time(),
            'services': overall.get('services', {})
        })
    # Non-local callers get minimal information to avoid leaking internal state
    return jsonify({'status': overall['status'].lower(), 'timestamp': time.time()}), 200


# ==================== Admin Routes (Session Login + API Key Fallback) ====================

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if is_admin_authenticated():
        return redirect(url_for('admin_dashboard'))

    client_ip = get_client_ip()
    error_message = ''
    next_url = request.args.get('next', '/admin/dashboard')
    if not _is_safe_next_url(next_url):
        next_url = '/admin/dashboard'

    if request.method == 'POST':
        next_url = request.form.get('next', '/admin/dashboard')
        if not _is_safe_next_url(next_url):
            next_url = '/admin/dashboard'

        if is_login_locked(client_ip):
            error_message = f"Too many failed attempts. Try again in {LOGIN_LOCK_SECONDS} seconds."
        else:
            password = request.form.get('password', '')
            if verify_admin_password(password):
                session.clear()
                session.permanent = True
                session['admin_authenticated'] = True
                session['admin_username'] = ADMIN_USERNAME
                session['admin_login_at'] = int(time.time())
                clear_login_failures(client_ip)
                return redirect(next_url)
            register_login_failure(client_ip)
            error_message = "Invalid password."

    return render_template_string(LOGIN_HTML, error_message=error_message, next_url=next_url)


@app.route('/admin/logout', methods=['GET', 'POST'])
def admin_logout():
    session.clear()
    return redirect(url_for('admin_login'))


@app.route('/admin/dashboard')
@require_admin
def admin_dashboard():
    # If access is via API key fallback, upgrade to session auth for dashboard XHR calls.
    if not session.get('admin_authenticated'):
        api_key = _get_admin_api_key()
        if api_key and hmac.compare_digest(api_key, ADMIN_API_KEY):
            session['admin_authenticated'] = True
            session['admin_username'] = ADMIN_USERNAME
            session['admin_login_at'] = int(time.time())
    return render_template_string(DASHBOARD_HTML)


@app.route('/admin/stats')
@require_admin
def admin_stats():
    # Lightweight audit log (avoid dumping sensitive headers/cookies)
    try:
        logger.info("Admin stats requested from %s", request.remote_addr)
    except Exception:
        logger.exception("Failed to log admin_stats request metadata")

    blocked_ips = list(detector.blocked_ips)
    blocked_details = [
        {'ip': ip, 'location': classify_ip_location(ip)} 
        for ip in blocked_ips
    ]

    return jsonify({
        'detection': detector.get_statistics(),
        'rate_limiter': rate_limiter.get_stats(),
        'traffic_analyzer': traffic_analyzer.get_stats(),
        'health': health_monitor.get_overall_health(),
        'attacks': notifier.get_attack_summary(),
        'blocked_ips': blocked_ips,
        'blocked_ip_details': blocked_details,
        'uptime': time.time() - app.config.get('start_time', time.time())
    })


@app.route('/admin/attacks')
@require_admin
def admin_attacks():
    recent_attacks = notifier.get_recent_attacks(50)
    return jsonify(recent_attacks)


@app.route('/admin/block/<ip>', methods=['POST'])
@require_admin
def admin_block_ip(ip):
    detector.blocked_ips.add(ip)
    logger.info("Admin manually blocked IP: %s", ip)
    return jsonify({'status': 'blocked', 'ip': ip})


@app.route('/admin/unblock/<ip>', methods=['POST'])
@require_admin
def admin_unblock_ip(ip):
    if detector.unblock_ip(ip):
        return jsonify({'status': 'unblocked', 'ip': ip})
    return jsonify({'status': 'not_found', 'ip': ip}), 404


@app.route('/admin/blocked')
@require_admin
def admin_blocked_list():
    blocked_ips = list(detector.blocked_ips)
    return jsonify({
        'blocked_ips': blocked_ips,
        'blocked_ip_details': [
            {'ip': ip, 'location': classify_ip_location(ip)}
            for ip in blocked_ips
        ],
        'count': len(blocked_ips)
    })


@app.route('/admin/snapshot')
@require_admin
def admin_snapshot():
    """Render a server-side snapshot of current stats suitable for screenshots."""
    stats = {
        'detection': detector.get_statistics(),
        'rate_limiter': rate_limiter.get_stats(),
        'traffic_analyzer': traffic_analyzer.get_stats(),
        'health': health_monitor.get_overall_health(),
        'attacks': notifier.get_attack_summary(),
        'blocked_ips': list(detector.blocked_ips),
        'uptime': time.time() - app.config.get('start_time', time.time())
    }
    recent = notifier.get_recent_attacks(20)
    # Format timestamps for readability
    for a in recent:
        try:
            a_ts = float(a.get('timestamp', time.time()))
            a['time_str'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(a_ts))
        except Exception:
            a['time_str'] = str(a.get('timestamp'))

    # Pretty uptime
    u = int(stats.get('uptime', 0))
    h = u // 3600
    m = (u % 3600) // 60
    s = u % 60
    if h > 0:
        uptime_str = f"{h}h {m}m {s}s"
    elif m > 0:
        uptime_str = f"{m}m {s}s"
    else:
        uptime_str = f"{s}s"

    return render_template_string(SNAPSHOT_HTML, stats=stats, recent=recent, uptime_str=uptime_str)


@app.route('/admin/snapshot_detailed')
@require_admin
def admin_snapshot_detailed():
    stats = {
        'detection': detector.get_statistics(),
        'rate_limiter': rate_limiter.get_stats(),
        'traffic_analyzer': traffic_analyzer.get_stats(),
        'health': health_monitor.get_overall_health(),
        'attacks': notifier.get_attack_summary(),
        'blocked_ips': list(detector.blocked_ips),
        'uptime': time.time() - app.config.get('start_time', time.time())
    }

    recent_attacks = notifier.get_recent_attacks(50)
    for a in recent_attacks:
        try:
            a_ts = float(a.get('timestamp', time.time()))
            a['time_str'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(a_ts))
        except Exception:
            a['time_str'] = str(a.get('timestamp'))

    # Build IP metrics from detector.ip_request_count
    ip_metrics = []
    for ip, dq in detector.ip_request_count.items():
        cnt = len(dq)
        last_seen = ''
        if cnt:
            try:
                last_seen = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(dq[-1]))
            except Exception:
                last_seen = str(dq[-1])
        ip_metrics.append({'ip': ip, 'count': cnt, 'last_seen': last_seen})
    # sort by count desc
    ip_metrics = sorted(ip_metrics, key=lambda x: x['count'], reverse=True)[:50]

    # sample recent requests from the traffic buffer
    recent_requests = []
    for m in list(detector.traffic_buffer)[-100:]:
        try:
            recent_requests.append({
                'time_str': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(m.timestamp)),
                'ip': m.ip_address,
                'method': m.method,
                'endpoint': m.endpoint,
                'status': m.status_code
            })
        except Exception:
            continue

    # pretty uptime
    u = int(stats.get('uptime', 0))
    h = u // 3600
    m = (u % 3600) // 60
    s = u % 60
    if h > 0:
        uptime_str = f"{h}h {m}m {s}s"
    elif m > 0:
        uptime_str = f"{m}m {s}s"
    else:
        uptime_str = f"{s}s"

    return render_template_string(SNAPSHOT_DETAILED_HTML,
                                  stats=stats,
                                  recent_attacks=recent_attacks,
                                  ip_metrics=ip_metrics,
                                  recent_requests=recent_requests,
                                  uptime_str=uptime_str)


# ==================== HTML Templates ====================

LOGIN_HTML = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - DDoS Protection</title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            display: grid;
            place-items: center;
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background:
                radial-gradient(70% 110% at 10% 0%, rgba(33, 96, 193, 0.35), transparent 60%),
                radial-gradient(60% 90% at 90% 10%, rgba(10, 73, 182, 0.3), transparent 65%),
                linear-gradient(180deg, #060b13 0%, #081426 100%);
            color: #d8e7ff;
        }
        .card {
            width: min(430px, 92vw);
            background: rgba(12, 27, 50, 0.82);
            border: 1px solid rgba(108, 163, 255, 0.24);
            border-radius: 16px;
            padding: 26px;
            box-shadow: 0 12px 30px rgba(1, 8, 15, 0.45);
        }
        h1 { margin: 0 0 4px 0; font-size: 1.8rem; }
        p { margin: 0 0 18px 0; color: #9eb9e5; }
        .field { margin-bottom: 14px; }
        label { display: block; margin-bottom: 7px; color: #b9cff2; font-size: 0.92rem; }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 11px 12px;
            border-radius: 10px;
            border: 1px solid rgba(121, 170, 235, 0.36);
            background: rgba(7, 16, 30, 0.96);
            color: #e7f0ff;
            outline: none;
        }
        input[readonly] { opacity: 0.85; }
        .btn {
            width: 100%;
            border: 0;
            border-radius: 10px;
            padding: 11px 14px;
            background: linear-gradient(145deg, #2a7cff, #1f5fcc);
            color: #fff;
            font-weight: 700;
            cursor: pointer;
        }
        .btn:hover { opacity: 0.95; }
        .error {
            margin-bottom: 12px;
            padding: 10px 12px;
            border-radius: 10px;
            border: 1px solid rgba(255, 118, 145, 0.45);
            background: rgba(64, 18, 28, 0.76);
            color: #ffc0cf;
            font-size: 0.9rem;
        }
        .hint {
            margin-top: 12px;
            color: #8ca8d6;
            font-size: 0.82rem;
        }
    </style>
</head>
<body>
    <form class="card" method="POST" action="/admin/login">
        <h1>Admin Login</h1>
        <p>Secure access to DDoS control dashboard.</p>
        {% if error_message %}
            <div class="error">{{ error_message }}</div>
        {% endif %}
        <input type="hidden" name="next" value="{{ next_url }}">
        <div class="field">
            <label>Username (locked)</label>
            <input type="text" value="admin" readonly>
        </div>
        <div class="field">
            <label for="password">Password</label>
            <input id="password" name="password" type="password" placeholder="Enter admin password" required autofocus>
        </div>
        <button class="btn" type="submit">Sign In</button>
        <div class="hint">Username is fixed to <strong>admin</strong>.</div>
    </form>
</body>
</html>'''

LANDING_PAGE_HTML = '''<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>DDoS Protected App</title>
    <style>
        body { font-family: Arial, sans-serif; background: linear-gradient(135deg, #667eea, #764ba2);
               display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
        .container { background: #fff; padding: 40px; border-radius: 20px; text-align: center;
                     box-shadow: 0 20px 60px rgba(0,0,0,0.3); max-width: 500px; }
        h1 { color: #667eea; margin-bottom: 10px; }
        .shield { font-size: 4em; margin-bottom: 20px; }
        p { color: #555; line-height: 1.6; }
        .status { margin-top: 20px; padding: 10px; background: #e8f5e9; border-radius: 8px;
                  color: #2e7d32; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <div class="shield">&#128737;</div>
        <h1>DDoS Protected Application</h1>
        <p>Your connection is protected by our multi-layered DDoS mitigation system.</p>
        <div class="status">Status: Protected</div>
    </div>
</body>
</html>'''


SNAPSHOT_DETAILED_HTML = '''<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Detailed Snapshot - DDoS Dashboard</title>
    <style>
        body{font-family:Arial,Helvetica,sans-serif;background:#f6f8fa;color:#0b1220;padding:20px}
        .header{display:flex;justify-content:space-between;align-items:center}
        .card{display:inline-block;padding:16px;border-radius:8px;background:#fff;margin:8px;border:1px solid #e1e4e8}
        .grid{display:flex;gap:12px;margin-top:12px;flex-wrap:wrap}
        table{width:100%;border-collapse:collapse;margin-top:12px}
        th,td{padding:8px;border-bottom:1px solid #e9ecef;text-align:left;font-size:13px}
        h2{margin:0}
        .col{width:48%}
    </style>
</head>
<body>
    <div class="header">
        <h2>Detailed DDoS Snapshot</h2>
        <div>Uptime: {{ uptime_str }}</div>
    </div>
    <div class="grid">
        <div class="card"><strong>Total Requests</strong><div style="font-size:24px">{{ stats.detection.total_requests }}</div></div>
        <div class="card"><strong>Attacks Detected</strong><div style="font-size:24px">{{ stats.detection.attacks_detected }}</div></div>
        <div class="card"><strong>IPs Blocked</strong><div style="font-size:24px">{{ stats.detection.blocked_ips_count }}</div></div>
        <div class="card"><strong>Traffic Buffer</strong><div style="font-size:20px">{{ stats.detection.traffic_buffer_size }} samples</div></div>
    </div>

    <h3 style="margin-top:18px">Top Attackers</h3>
    <table>
        <thead><tr><th>IP</th><th>Count</th></tr></thead>
        <tbody>
            {% if stats.attacks.top_attackers %}
                {% for ip, cnt in stats.attacks.top_attackers.items() %}
                    <tr><td>{{ ip }}</td><td>{{ cnt }}</td></tr>
                {% endfor %}
            {% else %}
                <tr><td colspan="2">No attackers recorded</td></tr>
            {% endif %}
        </tbody>
    </table>

    <div style="display:flex;gap:12px;margin-top:18px;align-items:flex-start">
        <div class="col">
            <h3>Recent Attacks</h3>
            <table>
                <thead><tr><th>Time</th><th>Type</th><th>Source IP</th><th>Severity</th><th>Confidence</th></tr></thead>
                <tbody>
                    {% if recent_attacks %}
                        {% for a in recent_attacks %}
                            <tr>
                                <td>{{ a.time_str }}</td>
                                <td>{{ a.attack_type }}</td>
                                <td>{{ a.source_ip }}</td>
                                <td>{{ a.severity }}</td>
                                <td>{{ '%.2f'|format(a.confidence) }}</td>
                            </tr>
                        {% endfor %}
                    {% else %}
                        <tr><td colspan="5">No recent attacks</td></tr>
                    {% endif %}
                </tbody>
            </table>
        </div>
        <div class="col">
            <h3>Per-IP Metrics (recent window)</h3>
            <table>
                <thead><tr><th>IP</th><th>Requests</th><th>Last Seen</th></tr></thead>
                <tbody>
                    {% if ip_metrics %}
                        {% for row in ip_metrics %}
                            <tr><td>{{ row.ip }}</td><td>{{ row.count }}</td><td>{{ row.last_seen }}</td></tr>
                        {% endfor %}
                    {% else %}
                        <tr><td colspan="3">No IP metrics</td></tr>
                    {% endif %}
                </tbody>
            </table>
        </div>
    </div>

    <h3 style="margin-top:18px">Recent Requests (sample)</h3>
    <table>
        <thead><tr><th>Time</th><th>IP</th><th>Method</th><th>Endpoint</th><th>Status</th></tr></thead>
        <tbody>
            {% if recent_requests %}
                {% for r in recent_requests %}
                    <tr><td>{{ r.time_str }}</td><td>{{ r.ip }}</td><td>{{ r.method }}</td><td>{{ r.endpoint }}</td><td>{{ r.status }}</td></tr>
                {% endfor %}
            {% else %}
                <tr><td colspan="5">No recent requests</td></tr>
            {% endif %}
        </tbody>
    </table>
</body>
</html>'''

DASHBOARD_HTML = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DDoS Protection Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <style>
        :root {
            --bg-color: #f0f4f8;
            --bg-gradient: linear-gradient(135deg, #f6f8fd 0%, #f1f5f9 100%);
            --card-bg: rgba(255, 255, 255, 0.7);
            --card-border: rgba(255, 255, 255, 0.8);
            --text-color: #1e293b;
            --text-muted: #64748b;
            --line-color: rgba(0, 0, 0, 0.08);
            --shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.07);
            --glass-blur: blur(16px);
            --btn-danger: linear-gradient(145deg, #ef4444, #dc2626);
            --btn-success: linear-gradient(145deg, #10b981, #059669);
            --input-bg: rgba(255, 255, 255, 0.9);
            --btn-text: #fff;
            
            --status-ok: #10b981;
            --status-warn: #f59e0b;
            --status-crit: #ef4444;
        }

        [data-theme="dark"] {
            --bg-color: #0f172a;
            --bg-gradient: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            --card-bg: rgba(30, 41, 59, 0.7);
            --card-border: rgba(255, 255, 255, 0.08);
            --text-color: #f8fafc;
            --text-muted: #94a3b8;
            --line-color: rgba(255, 255, 255, 0.08);
            --shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.3);
            --input-bg: rgba(15, 23, 42, 0.8);
            --btn-danger: linear-gradient(145deg, #ef4444, #b91c1c);
            --btn-success: linear-gradient(145deg, #10b981, #047857);
        }

        * { box-sizing: border-box; transition: background-color 0.3s, color 0.3s, border-color 0.3s; }
        
        body {
            margin: 0;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: var(--bg-gradient);
            background-attachment: fixed;
            color: var(--text-color);
            min-height: 100vh;
        }

        .shell { width: min(1460px, 96vw); margin: 20px auto; }
        
        .glass {
            background: var(--card-bg);
            backdrop-filter: var(--glass-blur);
            -webkit-backdrop-filter: var(--glass-blur);
            border: 1px solid var(--card-border);
            box-shadow: var(--shadow);
            border-radius: 16px;
        }

        .topbar {
            display: flex; justify-content: space-between; align-items: center; gap: 14px;
            padding: 16px 24px; margin-bottom: 24px;
        }
        
        .brand { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
        
        .shield {
            width: 40px; height: 40px; border-radius: 12px; display: grid; place-items: center;
            background: rgba(59, 130, 246, 0.15); border: 1px solid rgba(59, 130, 246, 0.3);
            font-size: 1.2rem;
        }
        
        .brand h1 { margin: 0; font-size: 1.6rem; font-weight: 700; }
        
        .site-chip {
            border: 1px solid var(--line-color); background: rgba(0,0,0,0.03);
            padding: 6px 12px; border-radius: 8px; font-size: 0.9rem;
        }
        [data-theme="dark"] .site-chip { background: rgba(255,255,255,0.03); }

        .actions { display: flex; gap: 16px; align-items: center; }
        
        .theme-toggle {
            background: var(--card-bg); border: 1px solid var(--card-border);
            color: var(--text-color); padding: 8px 12px; border-radius: 8px; cursor: pointer;
            font-weight: 500; font-size: 0.9rem;
        }
        .theme-toggle:hover { opacity: 0.8; }

        .status-wrap { display: flex; flex-direction: column; gap: 4px; align-items: flex-end; }
        
        .status-pill {
            display: inline-flex; align-items: center; gap: 8px; border-radius: 999px;
            border: 1px solid var(--card-border); background: var(--card-bg);
            padding: 6px 14px; font-size: 0.85rem; font-weight: 600;
        }
        
        .status-critical { color: var(--status-crit); border-color: rgba(239, 68, 68, 0.3); background: rgba(239, 68, 68, 0.1); }
        .status-degraded { color: var(--status-warn); border-color: rgba(245, 158, 11, 0.3); background: rgba(245, 158, 11, 0.1); }
        .status-unknown { color: var(--text-muted); }
        .dot { width: 8px; height: 8px; border-radius: 50%; background: var(--status-ok); box-shadow: 0 0 8px var(--status-ok); }
        
        .local-time { color: var(--text-muted); font-size: 0.8rem; }

        .metrics { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-bottom: 24px; }
        
        .metric { padding: 20px 24px; }
        
        .metric-label { font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px; font-weight: 600; }
        .metric-value { margin-top: 12px; font-size: 2.2rem; font-weight: 700; line-height: 1; color: var(--text-color); }

        .layout-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-bottom: 24px; }
        
        .card { padding: 20px 24px; }
        .card-head { font-size: 1.1rem; font-weight: 600; margin-bottom: 20px; color: var(--text-color); }
        .sub { color: var(--text-muted); font-size: 0.85rem; font-weight: 400; }

        .chart-shell, .pie-shell { position: relative; height: 320px; width: 100%; }

        .controls {
            display: flex; flex-wrap: wrap; align-items: center; gap: 12px; padding: 16px 24px;
            margin-bottom: 24px;
        }
        
        .ip-input {
            flex: 1; min-width: 220px; border: 1px solid var(--line-color); background: var(--input-bg);
            color: var(--text-color); border-radius: 8px; padding: 10px 14px; outline: none;
        }
        .ip-input:focus { border-color: rgba(59, 130, 246, 0.5); }
        
        .btn {
            border: none; border-radius: 8px; padding: 10px 18px; font-weight: 600; font-size: 0.9rem;
            cursor: pointer; color: var(--btn-text); transition: transform 0.2s, opacity 0.2s;
        }
        .btn:hover { transform: translateY(-1px); opacity: 0.9; }
        .btn-danger { background: var(--btn-danger); }
        .btn-success { background: var(--btn-success); }
        
        .btn-inline {
            border: 1px solid var(--line-color); background: transparent; color: var(--text-color);
            padding: 4px 12px; border-radius: 6px; font-size: 0.8rem; cursor: pointer; font-weight: 500;
        }
        .btn-inline:hover { background: rgba(0,0,0,0.05); }
        [data-theme="dark"] .btn-inline:hover { background: rgba(255,255,255,0.05); }

        .tables { display: grid; grid-template-columns: 1fr 1.5fr; gap: 20px; }
        
        .table-wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th, td { padding: 12px 16px; border-bottom: 1px solid var(--line-color); }
        th { font-size: 0.75rem; color: var(--text-muted); font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
        td { font-size: 0.9rem; }
        tr:last-child td { border-bottom: none; }

        .badge {
            border-radius: 999px; font-size: 0.7rem; padding: 4px 10px; font-weight: 600; letter-spacing: 0.5px;
        }
        .badge-critical { background: rgba(239, 68, 68, 0.15); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.2); }
        .badge-high { background: rgba(245, 158, 11, 0.15); color: #f59e0b; border: 1px solid rgba(245, 158, 11, 0.2); }
        .badge-medium { background: rgba(234, 179, 8, 0.15); color: #eab308; border: 1px solid rgba(234, 179, 8, 0.2); }
        .badge-low { background: rgba(16, 185, 129, 0.15); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.2); }
        .badge-safe { background: rgba(20, 184, 166, 0.15); color: #14b8a6; border: 1px solid rgba(20, 184, 166, 0.2); }

        .footer { margin-top: 24px; text-align: center; color: var(--text-muted); font-size: 0.8rem; }

        @media (max-width: 1024px) {
            .layout-grid, .tables { grid-template-columns: 1fr; }
            .topbar { flex-direction: column; align-items: stretch; gap: 20px; }
            .brand { justify-content: center; }
            .actions { justify-content: space-between; flex-wrap: wrap; }
        }
    </style>
</head>
<body>
<div class="shell">
    <div class="topbar glass">
        <div class="brand">
            <div class="shield">&#128737;</div>
            <h1>Dashboard</h1>
            <div id="siteChip" class="site-chip">Protected Site: --</div>
        </div>
        <div class="actions">
            <button class="theme-toggle" onclick="toggleTheme()" id="themeBtn">🌓 Dark Mode</button>
            <div class="status-wrap">
                <div id="systemStatus" class="status-pill status-unknown"><span class="dot"></span>System Status: Loading...</div>
                <div id="localTime" class="local-time">Local time: --:--:--</div>
                <a href="/admin/logout" style="color:var(--text-color);font-size:0.85rem;text-decoration:none;opacity:0.7;margin-top:4px;display:inline-block;">Logout</a>
            </div>
        </div>
    </div>

    <div class="metrics">
        <div class="metric glass"><div class="metric-label">Total Requests</div><div id="totalRequests" class="metric-value">0</div></div>
        <div class="metric glass"><div class="metric-label">Attacks Detected</div><div id="attacksDetected" class="metric-value">0</div></div>
        <div class="metric glass"><div class="metric-label">IP Blocked</div><div id="ipsBlocked" class="metric-value">0</div></div>
        <div class="metric glass"><div class="metric-label">System Uptime</div><div id="uptime" class="metric-value">0s</div></div>
    </div>

    <div class="layout-grid">
        <div class="card glass">
            <div class="card-head">Network Traffic Flow <span class="sub">(today 00:00-23:59)</span></div>
            <div class="chart-shell"><canvas id="trafficChart"></canvas></div>
        </div>
        <div class="card glass">
            <div class="card-head">Attack Types</div>
            <div class="pie-shell"><canvas id="attackTypeChart"></canvas></div>
        </div>
    </div>

    <div class="controls glass">
        <input type="text" id="ipInput" class="ip-input" placeholder="Enter IP address to block/unblock">
        <button class="btn btn-danger" onclick="blockIP()">Block IP</button>
        <button class="btn btn-success" onclick="unblockIP()">Unblock IP</button>
    </div>

    <div class="tables">
        <div class="card glass">
            <div class="card-head">Blocked IPs</div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>IP Address</th><th>Location</th><th>Action</th></tr></thead>
                    <tbody id="blockedTable"></tbody>
                </table>
            </div>
        </div>

        <div class="card glass">
            <div class="card-head">Recent Attacks</div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Time</th><th>Attack Type</th><th>Source IP</th><th>Location</th><th>Duration</th><th>Severity</th></tr></thead>
                    <tbody id="attacksTable"></tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="footerText" class="footer">Data source: /admin/stats, /admin/attacks - Updated: --</div>
</div>

<script>
// Theme toggling
function toggleTheme() {
    const body = document.body;
    const current = body.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : 'dark';
    body.setAttribute('data-theme', next);
    localStorage.setItem('dashboardTheme', next);
    document.getElementById('themeBtn').textContent = next === 'dark' ? '☀️ Light Mode' : '🌙 Dark Mode';
    if (trafficChart) updateChartColors(next);
}

const savedTheme = localStorage.getItem('dashboardTheme') || 'dark';
document.body.setAttribute('data-theme', savedTheme);
document.getElementById('themeBtn').textContent = savedTheme === 'dark' ? '☀️ Light Mode' : '🌙 Dark Mode';

function updateChartColors(theme) {
    if (!trafficChart || !attackTypeChart) return;
    const color = theme === 'dark' ? '#94a3b8' : '#64748b';
    const gridColor = theme === 'dark' ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)';
    
    Chart.defaults.color = color;
    Chart.defaults.borderColor = gridColor;
    
    trafficChart.options.scales.x.grid.color = gridColor;
    trafficChart.options.scales.y.grid.color = gridColor;
    trafficChart.options.scales.x.ticks.color = color;
    trafficChart.options.scales.y.ticks.color = color;
    trafficChart.update();
    attackTypeChart.update();
}

let trafficChart = null;
let attackTypeChart = null;
const DAY_LABELS = Array.from({ length: 24 }, (_, h) => `${String(h).padStart(2, '0')}:00`);
const trafficData = { labels: DAY_LABELS.slice(), requests: Array(24).fill(0), attacks: Array(24).fill(0), blocked: Array(24).fill(0) };
let chartDayKey = '';
let prevTotal = 0;
let prevAttacks = 0;
let prevBlocked = 0;

function getLocalDayKey(d) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
}

function resetDailySeries(now) {
    chartDayKey = getLocalDayKey(now);
    trafficData.labels = DAY_LABELS.slice();
    trafficData.requests = Array(24).fill(0);
    trafficData.attacks = Array(24).fill(0);
    trafficData.blocked = Array(24).fill(0);
    if (trafficChart) {
        trafficChart.data.labels = trafficData.labels;
        trafficChart.data.datasets[0].data = trafficData.requests;
        trafficChart.data.datasets[1].data = trafficData.attacks;
        trafficChart.update();
    }
}

function ensureTodaySeries(now, total, attacks, blocked) {
    const todayKey = getLocalDayKey(now);
    if (!chartDayKey || chartDayKey !== todayKey) {
        resetDailySeries(now);
        prevTotal = total;
        prevAttacks = attacks;
        prevBlocked = blocked;
    }
}

function fmtUptime(totalSeconds) {
    const secs = Math.max(0, Math.floor(totalSeconds || 0));
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    if (h > 0) return `${h}h ${m}m`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
}

function fmtDuration(durationSeconds) {
    const total = Math.max(0, Math.floor(durationSeconds || 0));
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = total % 60;
    if (h > 0) return `${h}h ${m}m ${s}s`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
}

function toStatusClass(status) {
    const st = (status || '').toLowerCase();
    if (st === 'healthy') return 'status-pill';
    if (st === 'critical') return 'status-pill status-critical';
    if (st === 'degraded') return 'status-pill status-degraded';
    return 'status-pill status-unknown';
}

function updateClock() {
    const now = new Date();
    const t = now.toLocaleTimeString();
    const el = document.getElementById('localTime');
    const footer = document.getElementById('footerText');
    if (el) el.textContent = `Local time: ${t}`;
    if (footer) footer.textContent = `Data source: /admin/stats, /admin/attacks - Updated: ${now.toLocaleDateString()} ${t}`;
}

const donutCenterText = {
    id: 'donutCenterText',
    afterDraw(chart) {
        if (chart.config.type !== 'doughnut') return;
        const total = chart.data.datasets[0].data.reduce((a, b) => a + (Number(b) || 0), 0);
        const meta = chart.getDatasetMeta(0);
        if (!meta || !meta.data || !meta.data.length) return;
        const x = meta.data[0].x;
        const y = meta.data[0].y;
        const ctx = chart.ctx;
        ctx.save();
        ctx.textAlign = 'center';
        ctx.fillStyle = document.body.getAttribute('data-theme') === 'dark' ? '#94a3b8' : '#64748b';
        ctx.font = '600 12px "Segoe UI", sans-serif';
        ctx.fillText('TOTAL ATTACKS', x, y - 5);
        ctx.fillStyle = document.body.getAttribute('data-theme') === 'dark' ? '#f8fafc' : '#1e293b';
        ctx.font = '700 28px "Segoe UI", sans-serif';
        ctx.fillText(String(total), x, y + 24);
        ctx.restore();
    }
};
Chart.register(donutCenterText);

function initCharts() {
    if (typeof Chart === 'undefined') return false;

    const theme = document.body.getAttribute('data-theme');
    const color = theme === 'dark' ? '#94a3b8' : '#64748b';
    const gridColor = theme === 'dark' ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)';

    Chart.defaults.color = color;
    Chart.defaults.borderColor = gridColor;
    Chart.defaults.font.family = "'Segoe UI', system-ui, sans-serif";

    const trafficCtx = document.getElementById('trafficChart').getContext('2d');
    const attackTypeCtx = document.getElementById('attackTypeChart').getContext('2d');

    trafficChart = new Chart(trafficCtx, {
        type: 'line',
        data: {
            labels: trafficData.labels,
            datasets: [
                {
                    label: 'Requests (daily cumulative)',
                    data: trafficData.requests,
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.15)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 0
                },
                {
                    label: 'Attacks (daily cumulative)',
                    data: trafficData.attacks,
                    borderColor: '#ef4444',
                    backgroundColor: 'rgba(239, 68, 68, 0.15)',
                    borderWidth: 2,
                    fill: false,
                    tension: 0.4,
                    pointRadius: 3,
                    pointHoverRadius: 5
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            scales: {
                x: {
                    grid: { color: gridColor, drawBorder: false },
                    ticks: {
                        color: color,
                        autoSkip: false,
                        maxRotation: 0,
                        callback: function(value, index) {
                            return index % 2 === 0 ? this.getLabelForValue(value) : '';
                        }
                    }
                },
                y: { 
                    beginAtZero: true,
                    grid: { color: gridColor, drawBorder: false },
                    ticks: { color: color, precision: 0 }
                }
            },
            plugins: { 
                legend: { labels: { boxWidth: 12, usePointStyle: true, pointStyle: 'circle' } },
                tooltip: { backgroundColor: 'rgba(15, 23, 42, 0.9)', titleColor: '#fff', bodyColor: '#fff', padding: 12, cornerRadius: 8 }
            }
        }
    });

    attackTypeChart = new Chart(attackTypeCtx, {
        type: 'doughnut',
        data: {
            labels: ['IP Flooding', 'Distributed', 'Behavioral'],
            datasets: [{
                data: [0, 0, 0],
                backgroundColor: ['#ef4444', '#f59e0b', '#10b981'],
                borderWidth: 0,
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: { 
                legend: { position: 'bottom', labels: { padding: 20, boxWidth: 10, usePointStyle: true, pointStyle: 'circle' } },
                tooltip: { backgroundColor: 'rgba(15, 23, 42, 0.9)', padding: 12, cornerRadius: 8 }
            }
        }
    });

    resetDailySeries(new Date());
    return true;
}

async function fetchStats() {
    try {
        const res = await fetch('/admin/stats', { credentials: 'same-origin' });
        if (res.status === 401) {
            window.location.href = '/admin/login';
            return;
        }
        const data = await res.json();

        const total = data.detection.total_requests || 0;
        const attacksDetected = data.detection.attacks_detected || 0;
        const blockedCount = data.detection.blocked_ips_count || 0;

        document.getElementById('totalRequests').textContent = total.toLocaleString();
        document.getElementById('attacksDetected').textContent = attacksDetected.toLocaleString();
        document.getElementById('ipsBlocked').textContent = blockedCount.toLocaleString();
        document.getElementById('uptime').textContent = fmtUptime(data.uptime || 0);

        const status = (data.health.status || 'unknown').toUpperCase();
        const statusEl = document.getElementById('systemStatus');
        statusEl.className = toStatusClass(status);
        statusEl.innerHTML = '<span class="dot"></span>System Status: ' + status;

        if (trafficChart) {
            const now = new Date();
            const blockedRequests = data.detection.blocked_requests || 0;
            ensureTodaySeries(now, total, attacksDetected, blockedRequests);
            const hourIndex = now.getHours();
            const reqDelta = Math.max(0, total - prevTotal);
            const atkDelta = Math.max(0, attacksDetected - prevAttacks);
            const blkDelta = Math.max(0, blockedRequests - prevBlocked);
            trafficData.requests[hourIndex] = Math.max(trafficData.requests[hourIndex] + reqDelta, total);
            trafficData.attacks[hourIndex] = Math.max(trafficData.attacks[hourIndex] + atkDelta, attacksDetected);
            trafficData.blocked[hourIndex] = Math.max(trafficData.blocked[hourIndex] + blkDelta, blockedRequests);
            prevTotal = total;
            prevAttacks = attacksDetected;
            prevBlocked = blockedRequests;
            trafficChart.update();
        }

        if (attackTypeChart) {
            const types = data.attacks.attack_types || {};
            attackTypeChart.data.datasets[0].data = [
                types['IP_FLOODING'] || 0,
                types['DDOS_DISTRIBUTED'] || 0,
                types['BEHAVIORAL_BLOCK'] || 0
            ];
            attackTypeChart.update();
        }

        const blockedTbody = document.getElementById('blockedTable');
        const blockedDetails = data.blocked_ip_details || [];
        blockedTbody.innerHTML = blockedDetails.map(function(item) {
            const ip = item.ip || 'N/A';
            const location = item.location || 'Unknown';
            return `<tr>
                <td>${ip}</td>
                <td>${location}</td>
                <td><button class="btn-inline" onclick="unblockDirect('${ip}')">Unblock</button></td>
            </tr>`;
        }).join('') || '<tr><td colspan="3" style="opacity:0.6">No blocked IPs</td></tr>';
    } catch (err) {
        console.error('Stats fetch failed:', err);
    }
}

async function fetchAttacks() {
    try {
        const res = await fetch('/admin/attacks?limit=10', { credentials: 'same-origin' });
        if (res.status === 401) {
            window.location.href = '/admin/login';
            return;
        }
        const attacks = await res.json();
        const tbody = document.getElementById('attacksTable');

        tbody.innerHTML = attacks.reverse().map(function(a) {
            const ts = Number(a.timestamp || (Date.now() / 1000));
            const t = new Date(ts * 1000).toLocaleTimeString();
            const sev = String(a.severity || 'LOW').toUpperCase();
            const sevCls = 'badge-' + sev.toLowerCase();
            const location = a.location || 'Unknown';
            const duration = fmtDuration(a.duration_seconds || 0);
            return `<tr>
                <td>${t}</td>
                <td>${a.attack_type || 'N/A'}</td>
                <td>${a.source_ip || 'N/A'}</td>
                <td>${location}</td>
                <td>${duration}</td>
                <td><span class="badge ${sevCls}">${sev}</span></td>
            </tr>`;
        }).join('') || '<tr><td colspan="6" style="opacity:0.6">No attacks recorded</td></tr>';
    } catch (err) {
        console.error('Attack fetch failed:', err);
    }
}

async function blockIP() {
    const ip = document.getElementById('ipInput').value.trim();
    if (!ip) return;
    const res = await fetch('/admin/block/' + ip, { method: 'POST', credentials: 'same-origin' });
    if (res.status === 401) {
        window.location.href = '/admin/login';
        return;
    }
    document.getElementById('ipInput').value = '';
    fetchStats();
    fetchAttacks();
}

async function unblockIP() {
    const ip = document.getElementById('ipInput').value.trim();
    if (!ip) return;
    const res = await fetch('/admin/unblock/' + ip, { method: 'POST', credentials: 'same-origin' });
    if (res.status === 401) {
        window.location.href = '/admin/login';
        return;
    }
    document.getElementById('ipInput').value = '';
    fetchStats();
    fetchAttacks();
}

async function unblockDirect(ip) {
    const res = await fetch('/admin/unblock/' + ip, { method: 'POST', credentials: 'same-origin' });
    if (res.status === 401) {
        window.location.href = '/admin/login';
        return;
    }
    fetchStats();
    fetchAttacks();
}

function startPolling() {
    const chip = document.getElementById('siteChip');
    if (chip) chip.textContent = 'Protected Site: https://www.hovernest.com/';
    updateClock();
    setInterval(updateClock, 1000);
    fetchStats();
    fetchAttacks();
    setInterval(fetchStats, 2000);
    setInterval(fetchAttacks, 5000);
}

(function bootstrap() {
    if (typeof Chart !== 'undefined') {
        initCharts();
        startPolling();
        return;
    }
    const fallback = document.createElement('script');
    fallback.src = 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js';
    fallback.onload = function () { initCharts(); startPolling(); };
    fallback.onerror = function () { startPolling(); };
    document.head.appendChild(fallback);
})();
</script>
</body>
</html>'''

app.config['start_time'] = time.time()


SNAPSHOT_HTML = '''<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Snapshot - DDoS Dashboard</title>
    <style>
        body{font-family:Arial,Helvetica,sans-serif;background:#f6f8fa;color:#0b1220;padding:20px}
        .header{display:flex;justify-content:space-between;align-items:center}
        .card{display:inline-block;padding:16px;border-radius:8px;background:#fff;margin:8px;border:1px solid #e1e4e8}
        .grid{display:flex;gap:12px;margin-top:12px}
        table{width:100%;border-collapse:collapse;margin-top:12px}
        th,td{padding:8px;border-bottom:1px solid #e9ecef;text-align:left;font-size:14px}
        h2{margin:0}
    </style>
</head>
<body>
    <div class="header">
        <h2>DDoS Protection Snapshot</h2>
        <div>Uptime: {{ uptime_str }}</div>
    </div>
    <div class="grid">
        <div class="card"><strong>Total Requests</strong><div style="font-size:24px">{{ stats.detection.total_requests }}</div></div>
        <div class="card"><strong>Attacks Detected</strong><div style="font-size:24px">{{ stats.detection.attacks_detected }}</div></div>
        <div class="card"><strong>IPs Blocked</strong><div style="font-size:24px">{{ stats.detection.blocked_ips_count }}</div></div>
        <div class="card"><strong>Blocked List</strong><div style="font-size:14px">{{ stats.blocked_ips|length }} entries</div></div>
    </div>

    <h3 style="margin-top:18px">Blocked IPs</h3>
    <table>
        <thead><tr><th>IP</th></tr></thead>
        <tbody>
            {% if stats.blocked_ips %}
                {% for ip in stats.blocked_ips %}
                    <tr><td>{{ ip }}</td></tr>
                {% endfor %}
            {% else %}
                <tr><td>No blocked IPs</td></tr>
            {% endif %}
        </tbody>
    </table>

    <h3 style="margin-top:18px">Recent Attacks</h3>
    <table>
        <thead><tr><th>Time</th><th>Type</th><th>Source IP</th><th>Severity</th></tr></thead>
        <tbody>
            {% if recent %}
                {% for a in recent %}
                    <tr>
                        <td>{{ a.time_str }}</td>
                        <td>{{ a.attack_type }}</td>
                        <td>{{ a.source_ip }}</td>
                        <td>{{ a.severity }}</td>
                    </tr>
                {% endfor %}
            {% else %}
                <tr><td colspan="4">No recent attacks</td></tr>
            {% endif %}
        </tbody>
    </table>
</body>
</html>'''

@app.route('/metrics')
def metrics():
    """Prometheus metrics export endpoint."""
    stats = detector.get_statistics()
    health_status = health_monitor.get_overall_health()['status']
    is_healthy = 1 if health_status == 'HEALTHY' else 0
    
    lines = [
        "# HELP ddos_total_requests Total number of HTTP requests processed by the DDoS engine.",
        "# TYPE ddos_total_requests counter",
        f"ddos_total_requests {stats.get('total_requests', 0)}",
        "# HELP ddos_attacks_detected Total number of DDoS attacks detected.",
        "# TYPE ddos_attacks_detected counter",
        f"ddos_attacks_detected {stats.get('attacks_detected', 0)}",
        "# HELP ddos_blocked_ips_count Current number of IPs blocked.",
        "# TYPE ddos_blocked_ips_count gauge",
        f"ddos_blocked_ips_count {stats.get('blocked_ips_count', 0)}",
        "# HELP ddos_blocked_requests Total number of requests blocked.",
        "# TYPE ddos_blocked_requests counter",
        f"ddos_blocked_requests {stats.get('blocked_requests', 0)}",
        "# HELP ddos_system_health Current health status (1 for healthy, 0 for otherwise).",
        "# TYPE ddos_system_health gauge",
        f"ddos_system_health {is_healthy}",
    ]
    
    return app.response_class(
        response='\\n'.join(lines) + '\\n',
        status=200,
        mimetype='text/plain; version=0.0.4'
    )

if __name__ == '__main__':
    logger.info("Starting DDoS Protected Web Application on port 8000")
    app.run(host='0.0.0.0', port=8000, debug=False, threaded=True)
